# Gas-Detection-Alarm
Gas Detection Alarm using Tinkercad. This is an ardunio based Project
![Screenshot_1](https://user-images.githubusercontent.com/72695590/129707418-818e9f91-3606-4b47-9b4d-145fe15e9047.png)
![Screenshot_2](https://user-images.githubusercontent.com/72695590/129707431-ec2139e2-c973-4532-b611-7cbdcd6bc2b7.png)
